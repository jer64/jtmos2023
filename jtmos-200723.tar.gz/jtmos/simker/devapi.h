#ifndef __INCLUDED_SIMKER32_H__
#define __INCLUDED_SIMKER32_H__

//
/*** Basic Definations ***/
#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef DWORD
#define DWORD unsigned long int
#endif

#ifndef WORD
#define WORD unsigned short int
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

//
#ifndef BOOL
#define BOOL BYTE
#endif

#endif

//
#ifndef __INCLUDED_CONNECTHOST_H__
#define __INCLUDED_CONNECTHOST_H__

//
SOCKET *ConnectHost(DWORD dstip, int dstport);

#endif





#ifndef __INCLUDED_SLIP_H__
#define __INCLUDED_SLIP_H__

// Something here:
int slip_init(void);

#endif

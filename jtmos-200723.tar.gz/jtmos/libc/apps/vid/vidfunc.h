#ifndef __INCLUDED_VIDFUNC_H__
#define __INCLUDED_VIDFUNC_H__

//
int fexist(const char *fname);

#endif




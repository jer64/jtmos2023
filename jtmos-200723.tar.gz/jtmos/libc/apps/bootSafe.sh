#
echo "JTMOS safe mode start up script"


#ifndef __INCLUDED_MKANPCX_H__
#define __INCLUDED_MKANPCX_H__

//
#define pcx_header 128

//
int decode_pcxto(unsigned char *_srcfname,char *_buffer,unsigned char _paletteadd);
                // Last parameter = Add palette (0=False, 1=True)

#endif

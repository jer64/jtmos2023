#ifndef __INCLUDED_MKANSTRETCH_H__
#define __INCLUDED_MKANSTRETCH_H__

//
void jtmgl_stretchputimage1(char *vbuffer,long jwidth,long jheight,long outbpp,
        char *t, int width,int height, int xs,int ys,int xm,int ym,long srcbpp);

#endif



#!/bin/bash
cd gui
make
cd ..


#ifndef __INCLUDED_GUIEND_H__
#define __INCLUDED_GUIEND_H__

#include <stdio.h>
#include "graos.h"

void guiEnd(VMODE *v);

#endif


#ifndef __INCLUDED_GUISERVER_H__
#define __INCLUDED_GUISERVER_H__

//
#include "graosprotocol.h"

//
void guiServerInit(void);
int guiServerProcessMessage(VMODE *v, MSG *m);
void guiServerPoll(VMODE *v);

#endif



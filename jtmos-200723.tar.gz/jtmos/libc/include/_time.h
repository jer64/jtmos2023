#ifndef __INCLUDED__TIME_H__
#define __INCLUDED__TIME_H__

#include <jtmos/date.h>

#endif

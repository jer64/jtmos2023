#ifndef __INCLUDED_JTMLIBC_SCANF_H__
#define __INCLUDED_JTMLIBC_SCANF_H__

int scanf(const char *format, ...);

#endif



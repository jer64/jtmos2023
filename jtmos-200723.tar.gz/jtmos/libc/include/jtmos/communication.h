//
#ifndef __INCLUDED_COMMUNICATION_H__
#define __INCLUDED_COMMUNICATION_H__

//
int SerialGet(int n_port);
int SerialPut(int n_port, int ch);
int SerialPuts(int n_port, const char *s);
int SerialWaitString(int portNr, const char *strLogin, int tmOutSecs);
void SetSerialPortSpeed(int portNr, int bps);

#endif




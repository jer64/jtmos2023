#ifndef __INCLUDED_JTMLIBC_ENV_H__
#define __INCLUDED_JTMLIBC_ENV_H__

int setenv(const char *name, const char *value, int overwrite);
void unsetenv(const char *name);
char *getenv(const char *name);
int putenv(const char *fmt);

#endif


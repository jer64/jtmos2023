#ifndef __INCLUDED_JTMLIBC_FLOORL_H__
#define __INCLUDED_JTMLIBC_FLOORL_H__

long double floorl (long double x);

#endif


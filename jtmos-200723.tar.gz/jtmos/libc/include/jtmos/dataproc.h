//
#ifndef __INCLUDED_JTMLIBC_DATAPROC_H_1__
#define __INCLUDED_JTMLIBC_DATAPROC_H_1__

//
#include <stdio.h>
#include "jtmos/ctypefamily.h"
#include "jtmos/float.h"
#include "jtmos/floatconv.h"
#include "jtmos/floor.h"
#include "jtmos/floorl.h"
#include "jtmos/hexdump.h"
#include <jtmos/ieee754.h>
#include <jtmos/limits.h>
#include <jtmos/mathl.h>
#include <jtmos/modf.h>
#include <jtmos/numbers.h>
#include <jtmos/printf.h>
#include <jtmos/qsort.h>
#include <jtmos/sprintf.h>
#include <jtmos/sscanf.h>
#include <jtmos/stdarg.h>
#include <jtmos/strchr.h>
#include <jtmos/string.h>
#include <jtmos/strncat.h>
#include <jtmos/strpbrk.h>
#include <jtmos/memcmp.h>

#endif




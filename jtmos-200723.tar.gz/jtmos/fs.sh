#!/bin/bash
dd if=/dev/zero of=fs.bin count=32

#

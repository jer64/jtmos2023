#!/bin/bash
gcc -O2 -o pdump pdump.c


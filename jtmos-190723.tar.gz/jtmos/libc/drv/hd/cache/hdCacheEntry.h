#ifndef __INCLUDED_HDCACHEENTRY_H__
#define __INCLUDED_HDCACHEENTRY_H__

//
int hdArrangeFreeEntry(void);
void hdArrangeMoreFreeEntries(HCDB *h);

#endif






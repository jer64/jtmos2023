#ifndef __INCLUDED_DHD_DEV_H__
#define __INCLUDED_DHD_DEV_H__

//
int dhd_device_call(DEVICE_CALL_PARS);
int dhd_register_device(void);

#endif

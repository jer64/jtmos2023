// DUMMY FILE - DO NOT CARE.
// Just a fix, because some files still include old hd.h..

// dhd_schedule.h
#ifndef __INCLUDED_SCHEDULE_H__
#define __INCLUDED_SCHEDULE_H__

#define SCHEDULE nop
//#define SCHEDULE idle_moment

#endif




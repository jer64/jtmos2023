#ifndef __INCLUDED_HDRESET_H__
#define __INCLUDED_HDRESET_H__

//
#include <stdio.h>
#include "hd.h"

//
void hdReset1(void);
void hdReset(HD *h);

#endif




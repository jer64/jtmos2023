#ifndef __INCLUDED_MODAL_H__
#define __INCLUDED_MODAL_H__

typedef struct malloc_chunk* mchunkptr;
mchunkptr malloc_from_sys(unsigned nb);

#endif


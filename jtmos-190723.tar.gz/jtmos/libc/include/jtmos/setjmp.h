#ifndef __INCLUDED_SETJMP_H__
#define __INCLUDED_SETJMP_H__

/*typedef struct
{
    __jmp_buf __jmpbuf;		// Calling environment.
    int __mask_was_saved;	// Saved the signal mask?
    sigset_t __saved_mask;	// Saved signal mask.
}sigjmp_buf[1];*/

#endif


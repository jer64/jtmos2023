//
#ifndef __INCLUDED_STRCHR_H__
#define __INCLUDED_STRCHR_H__

//
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);

#endif


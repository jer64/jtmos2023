#ifndef __INCLUDED_MOUSE_H__
#define __INCLUDED_MOUSE_H__

int GetMouseX(void);
int GetMouseY(void);
int GetMouseButtons(void);
int SetMouseRect(int x1,int y1,int x2,int y2);

#endif

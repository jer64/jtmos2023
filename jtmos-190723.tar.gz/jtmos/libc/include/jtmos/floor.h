#ifndef __INCLUDED_JTMLIBC_FLOOR_H__
#define __INCLUDED_JTMLIBC_FLOOR_H__

double floor(double x);

#endif


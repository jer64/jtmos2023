#ifndef __INCLUDED_JTMLIBC_TMPNAM_H__
#define __INCLUDED_JTMLIBC_TMPNAM_H__

char *tmpnam(char *s);

#endif


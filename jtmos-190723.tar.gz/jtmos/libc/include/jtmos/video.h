#ifndef __INCLUDED_VIDEO_H__
#define __INCLUDED_VIDEO_H__

//
int setmode(int vmode);
int drawframe(const char *buf, int offs, int len);
int drawframe1(const char *buf, int offs, int len);
int setpalettemap(int offs, int amount, BYTE *paldata);
int setpalette(int which, int r,int g,int b);
void waitretrace(void);
int vgaselectplane(int which);
int setvmode(int vmode);

#endif

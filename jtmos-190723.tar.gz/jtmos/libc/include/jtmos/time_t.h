//
#ifndef __INCLUDED_TIME_T_H__
#define __INCLUDED_TIME_T_H__

//
#ifndef _TIME_T
#define _TIME_T
typedef long time_t;
#endif

#endif




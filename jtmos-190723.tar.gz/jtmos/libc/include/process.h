//
#ifndef __ALTINC_PROCESS_H__
#define __ALTINC_PROCESS_H__

//
#include <jtmos/process.h>

#endif

//


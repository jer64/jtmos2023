//
#include <stdio.h>

//
struct
{
 int a,b,c,d;
}bla;

//
int main(int argc,char **argv)
{
 //
 char *hellostr="blabla";
/*
 struct
 {
  int a,b,c,d;
 }bla;
*/
 unsigned long int ad;
 void *p;

 //
 p=&bla;
 printf("hellostr=%1.8x, bla=%x\n",	hellostr, &bla);

 //
 return 0;
}

//

#ifndef __INCLUDED_VPLAY_H__
#define __INCLUDED_VPLAY_H__

//
#include "vidpak.h"
#include "vidhdr.h"
#include "vplayGraph.h"
#include "vplayView.h"

//
extern int fastMode;

#endif



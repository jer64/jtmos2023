#ifndef __INCLUDED_MKANVIC_H__
#define __INCLUDED_MKANVIC_H__

//
void jtm_hiresplot(unsigned char *frame,int x,int y,int c);
void jtm_hirescut(unsigned char *frame,int x,int y,int c);
int jtm_hiresread(unsigned char *frame,int x,int y);
void jtm_multiplot(unsigned char *frame,int _x,int _y,int _c);

#endif





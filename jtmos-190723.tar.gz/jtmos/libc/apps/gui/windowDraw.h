#ifndef __INCLUDED_WINDOWDRAW_H__
#define __INCLUDED_WINDOWDRAW_H__

//
int buttonDraw(VMODE *v,
        int x1,int y1,int x2,int y2,
        int pressed,
        const char *caption);
int windowDraw(VMODE *v, WINDOW *w);
int drawFB(VMODE *v, WINDOW *w, FRAMEBUF *fb);
int drawWindowFrameBuffers(VMODE *v, WINDOW *w);

#endif

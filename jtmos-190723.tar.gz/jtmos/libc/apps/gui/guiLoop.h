#ifndef __INCLUDED_GUILOOP_H__
#define __INCLUDED_GUILOOP_H__

#include <stdio.h>
#include "graos.h"
void guiLoop(VMODE *v);

#endif


#ifndef __INCLUDED_CONFIG_H__
#define __INCLUDED_CONFIG_H__

//
extern int XON_SYSTEM_METERS;

#endif



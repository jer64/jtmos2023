#ifndef __INCLUDED_WINDOWORDER_H__
#define __INCLUDED_WINDOWORDER_H__

//
int putWindowOnTop(VMODE *v, WINDOW *w);

#endif



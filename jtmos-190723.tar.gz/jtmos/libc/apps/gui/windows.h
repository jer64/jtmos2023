#ifndef __INCLUDED_WINDOWS_H__
#define __INCLUDED_WINDOWS_H__

//
#include <stdio.h>
#include "graos.h"

//
int guiWindowSystemCall(VMODE *v);
int moveWindowAt(WINDOW *w, int x,int y);
int windowX(WINDOW *w);
int windowY(WINDOW *w);
int windowFollow(WINDOW *w, int x,int y);
void CloseDebugStream(void);
void OpenDebugStream(const char *name);
void DebugMessage(const char *s);
void exitAllApplications(VMODE *v);

#endif



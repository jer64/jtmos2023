#ifndef __INCLUDED_GUIUPDATE_H__
#define __INCLUDED_GUIUPDATE_H__

#include <stdio.h>
#include "graos.h"
void guiUpdate(VMODE *v);

#endif


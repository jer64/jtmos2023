#!/bin/bash
gcc -w -O3 -m486 -o nzip nzip.c
#echo "Installing binary ..."
#su -c 'cp nzip /bin'


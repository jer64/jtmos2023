#!/bin/bash
# -curses
# qemu-system-i386
# kvm
qemu-system-i386 -fda jtm32.img -m 512 -hda hd_jtmos.img -boot a
#kvm -fda jtm32.img -m 512 -hda hd_jtmos.img -boot a

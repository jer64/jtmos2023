#ifndef __INCLUDED_BASDEF_H__
#define __INCLUDED_BASDEF_H__

#include "simker.h"

#endif

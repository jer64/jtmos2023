#ifndef __INCLUDED_GUIARROW_H__
#define __INCLUDED_GUIARROW_H__

void UndoOldArrow(VMODE *v);
void StoreNewArrow(VMODE *v);

#endif


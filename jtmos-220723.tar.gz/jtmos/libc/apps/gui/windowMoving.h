#ifndef __INCLUDED_WINDOWMOVING_H__
#define __INCLUDED_WINDOWMOVING_H__

//
#include "graos.h"

//
int windowMoving(VMODE *v);

#endif


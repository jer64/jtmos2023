#ifndef __INCLUDED_COLLISION_H__
#define __INCLUDED_COLLISION_H__

//
int EstimateWindowCollision(WINDOW *ww);
int RedrawCollisionedWindows(VMODE *v);

#endif



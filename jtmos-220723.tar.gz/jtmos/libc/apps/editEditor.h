//
#ifndef __INCLUDED_EDITEDITOR_H__
#define __INCLUDED_EDITEDITOR_H__

//
int Editor(const char *fname);

#endif


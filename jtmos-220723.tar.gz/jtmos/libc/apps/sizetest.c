main()
{
 printf("float size=%d bytes, double size=%d bytes\n",
        sizeof(float), sizeof(double));
}


#ifndef __INCLUDED_MKANUSER_H__
#define __INCLUDED_MKANUSER_H__

//
void waitkey(void);

#endif


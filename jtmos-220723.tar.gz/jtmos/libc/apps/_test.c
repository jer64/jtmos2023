// This program performs some basic checks about the present memory configuration
// of the application, and tells about it to the user via stdout.
//
#include <stdio.h>

//
extern DWORD appregionstart,end;

//
int main(int argc,char **argv)
{
 //
 printf("Hello world!\n");

 //
 return 0;
}

//


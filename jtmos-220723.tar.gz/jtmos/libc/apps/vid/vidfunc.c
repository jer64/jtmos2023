// vidfunc.c
#include <stdio.h>
#include "vidpak.h"
#include "vidfunc.h"

//
#ifndef JTMOS
int fexist(const char *fname)
{
	FILE *f;

	//
	f = fopen(fname, "rb");
	if(f==NULL)
		return 0;
	fclose(f);
	return 1;
}
#endif





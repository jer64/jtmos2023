//
extern int errno;

//


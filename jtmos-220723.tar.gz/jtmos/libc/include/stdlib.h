// Turbo C emulation
#include <stdio.h>

//
#define HAVE_STDLIB

/* We define these the same for all machines.
   Changes from this to the outside world should be done in
`_exit'.  */
#define	EXIT_FAILURE	1	/* Failing exit status.  */
#define	EXIT_SUCCESS	0	/* Successful exit status.  */


/* Maximum length of a multibyte character in the current locale.
   This is just one until the fancy locale support is
finished.  */
#define	MB_CUR_MAX	1

/* The largest number rand will return (same as INT_MAX).  */
#define	RAND_MAX	2147483647

//
#include "jtmos/random.h"


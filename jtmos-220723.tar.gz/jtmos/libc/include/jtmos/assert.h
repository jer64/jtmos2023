#ifndef __INCLUDED_ASSERT_H__
#define __INCLUDED_ASSERT_H__

void assert (int expression);

#endif


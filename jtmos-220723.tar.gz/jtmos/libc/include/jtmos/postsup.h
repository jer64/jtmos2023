//
#ifndef __INCLUDED_POSTSUP_H__
#define __INCLUDED_POSTSUP_H__

//
#include "process.h"
#include "postman.h"
int PostmanWaitAck(POSTMANCMD *p);
int PostmanPost(POSTMANCMD *p);

#endif

//
#ifndef __INCLUDED_FPRINTF_H__
#define __INCLUDED_FPRINTF_H__

//
int fprintf(FILE *fd, const char *fmt, ...);
int vfprintf(FILE *fd, const char *fmt, va_list args);
//int vfprintf(FILE *fd, const char *fmt, ...);

#endif






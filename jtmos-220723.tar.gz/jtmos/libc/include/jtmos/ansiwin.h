#ifndef __INCLUDED_ANSIWIN_H__
#define __INCLUDED_ANSIWIN_H__

//
void DrawAnsiWindow(int x1,int y1,int x2,int y2,
                int type, char *headline,int fill);

#endif

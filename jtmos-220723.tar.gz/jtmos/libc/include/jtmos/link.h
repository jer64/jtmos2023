#ifndef __INCLUDED_LINK_H__
#define __INCLUDED_LINK_H__

int unlink(const char *pathname);
int link(const char *oldpath, const char *newpath);

#endif



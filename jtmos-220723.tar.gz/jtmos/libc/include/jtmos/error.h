//
#ifndef __INCLUDED_ERROR_H__
#define __INCLUDED_ERROR_H__

//
#include "stdarg.h"

//
void perror(char * prefix);
void LIBCERROR(const char *apfmt, va_list aparg);
void panic(const char *s);

//
#endif

//

//
#ifndef __INCLUDED_SYSCHKSUM_H__
#define __INCLUDED_SYSCHKSUM_H__

//
DWORD syschksum(BYTE *buf, int len);

#endif



#ifndef __INCLUDED_JTMLIBC_MODF_H__
#define __INCLUDED_JTMLIBC_MODF_H__

double modf(double x, double *iptr);

#endif

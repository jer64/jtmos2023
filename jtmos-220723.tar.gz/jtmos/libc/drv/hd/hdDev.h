#ifndef __INCLUDED_HDDEV_H__
#define __INCLUDED_HDDEV_H__

//
#include <jtmos/dcpacket.h>

//
int hdDeviceCall(
        DCPACKET *dc,
        int clientPID, int n_call,
        int p1,int p2,int p3,int p4,
        void *po1,void *po2);
int hdRegisterDevice(void);

#endif

#ifndef __INCLUDED_DHD_DETECT_H__
#define __INCLUDED_DHD_DETECT_H__

#include "kernel32.h"
#include "dhd.h"

int GetHDParam(HDSPEC *h, int drive, WORD *hdp);

#endif

//
#ifndef __INCLUDED_RAMSERVICE_H__
#define __INCLUDED_RAMSERVICE_H__

//
void ramServiceInit(void);

#endif





